#include "stdafx.h"
#include "CSI4133.h"

CSI4133::CSI4133(){
	vidOriginal = 0;
	vidProcessed = 0;
	thresh = 0;;
}

CSI4133::~CSI4133(){
	cvDestroyAllWindows();
	if (vidOriginal)
		delete vidOriginal;
	if (vidProcessed)
		delete vidProcessed;
}

bool CSI4133::loadVideoPath(CString * _path){
	CFileDialog dlg(TRUE, _T("*.avi"), NULL, OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_HIDEREADONLY,_T("video files (*.avi; *.mpeg) |*.avi;*.mpeg|All Files (*.*)|*.*||"),NULL);
	dlg.m_ofn.lpstrTitle= _T("Open Video");

	if (dlg.DoModal() == IDOK) {
		*_path = dlg.GetPathName();
		return true;
	} else {
		return false;
	}
}

bool CSI4133::saveVideoPath(CString * _path){
	CFileDialog dlg(TRUE, _T("*.avi"), NULL, OFN_PATHMUSTEXIST|OFN_HIDEREADONLY,_T("video files (*.avi; *.mpeg) |*.avi;*.mpeg|All Files (*.*)|*.*||"),NULL);
	dlg.m_ofn.lpstrTitle= _T("save Video");

	if (dlg.DoModal() == IDOK) {
		*_path = dlg.GetPathName();
		return true;
	} else {
		return false;
	}
}

bool CSI4133::loadVideo(CString * _str){
	if (loadVideoPath(_str)){
		if (vidOriginal)
			delete vidOriginal;
		if (vidProcessed)
			delete vidProcessed;
		
		CvCapture *tmpCap = cvCaptureFromAVI(*_str);

		vidOriginal = new ImgArr(tmpCap);
		vidProcessed = new ImgArr(vidOriginal);

		cvReleaseCapture(&tmpCap);

		return true;
	} else {
		return false;
	}
}

void CSI4133::showVideo(ImgArr * _arr, CString _title){
	int key = 0;
	if (_arr){
		for (int i = 0; i < _arr->nFrames && key != 'q'; i++){
			cvShowImage(_title, _arr->frames[i]);
			key = cvWaitKey(1000/_arr->fps);
		}
	}else{
		MessageBox(NULL, "Video not yet loaded","Error", MB_OK);
	}
}

void CSI4133::showImage(CString _name, IplImage * _img){
	if (_img)
		cvShowImage(_name, _img);
	else
		MessageBox(NULL, "Image cannot be shown: not yet loaded","Error", MB_OK);
}

void CSI4133::trackbarChange(int _val1, void * _val2){
	((CSI4133*)_val2)->processTest();
}

void CSI4133::processTest(){
	if (vidOriginal){
		cvNamedWindow("Test Window",1);			
		cvCreateTrackbar2("Value", "Test Window", &thresh, 1000, trackbarChange, this);
		updateSlider();
	} else {
		MessageBox(NULL, "Original video not yet loaded", "Error", MB_OK);
	}
}

void CSI4133::updateSlider(){
	//Test out anything you'd like here.
}

void CSI4133::processVideo(){
	
	if (vidOriginal && vidProcessed){
		vidProcessed->clearFrames();
		// Input: class variable 'vidOriginal'
		// Output: class variable 'vidProcessed'
		//<Student's Code>

		//</Student's Code>
		showVideo(vidProcessed, "Processed Video");
	} else {
		MessageBox(NULL, "Video not yet loaded","Error", MB_OK);
	}	
}

void CSI4133::saveVideo(ImgArr * _arr){
	CString path;
	CvVideoWriter * writer;
	if (vidOriginal && vidProcessed){
		if (saveVideoPath(&path)){
			CvSize dim = cvSize(_arr->frmWidth, _arr->frmHeight);
			int tempDepth = _arr->frmDepth;
			if(writer = cvCreateVideoWriter(path, -1, vidOriginal->fps, dim)){
				for (int i = 0 ; i < _arr->nFrames;i++)
					cvWriteFrame(writer, _arr->frames[i]);
				cvReleaseVideoWriter(&writer);
			}
		}
	} else{
		MessageBox(NULL, "Video not yet loaded","Error", MB_OK);
	}
}

void CSI4133::saveProcessedVideo(){
	saveVideo(vidProcessed);
}